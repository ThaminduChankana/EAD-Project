/*
 * File: LocalIP.js
 * Description: This file contains the Local IP address of the web service.
 */
var LocalIP = "https://localhost:44382/";

export default LocalIP;
