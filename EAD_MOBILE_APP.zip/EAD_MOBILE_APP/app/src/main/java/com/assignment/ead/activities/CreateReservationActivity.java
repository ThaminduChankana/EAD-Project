/*
 * File: CreateReservationActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to add a train reservation.
 * References: https://www.youtube.com/watch?v=xPi-z3nOcn8&t=491s
 *             https://www.youtube.com/watch?v=Sn40j_8IO70&list=PLU26ZOU7iGRP6dbnK2a43hxxJQLoR55Ca&index=3
 *             https://www.youtube.com/watch?v=o1m2RicWnjo
 */
package com.assignment.ead.activities;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.R;
import com.assignment.ead.models.SpinnerItemModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CreateReservationActivity extends AppCompatActivity {

    private static final int MAX_TICKET_COUNT = 4;

    // UI elements
    private Button confirmButton;
    private Spinner trainSpinner;
    private EditText travelDate, travelTime, startStation, endStation, ticketPrice, ticketCount, totalPrice;
    private String selectedTrainValue = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the content view to the reservation activity layout
        setContentView(R.layout.activity_create_reservation);

        // Get user preferences
        SharedPreferences userPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);

        // Initialize UI elements
        initializeViews();

        // Set up event listeners
        setupListeners(userPreferences);

        // Load train data from the server
        loadTrainData();
    }

    // Initialize UI elements by finding their respective views by their IDs
    private void initializeViews() {
        trainSpinner = findViewById(R.id.create_booking_train);
        travelDate = findViewById(R.id.create_booking_date);
        travelTime = findViewById(R.id.create_booking_time);
        startStation = findViewById(R.id.create_booking_start);
        endStation = findViewById(R.id.create_booking_end);
        ticketPrice = findViewById(R.id.create_booking_price);
        ticketCount = findViewById(R.id.create_booking_no_of_ticket);
        totalPrice = findViewById(R.id.create_booking_total);
        confirmButton = findViewById(R.id.create_booking_btn);
    }

    // Set up event listeners for buttons and input fields
    private void setupListeners(final SharedPreferences userPreferences) {
        // Set an onClickListener for the confirm button
        confirmButton.setOnClickListener(v -> {
            if (isTrainSelected() && isTicketCountValid() && isTotalPriceValid() && isReservationDateValid()) {
                postTicketData(userPreferences);
            } else {
                showToast("Please check your input fields.");
            }
        });

        // Add a TextWatcher to the ticketCount EditText to update the total price
        ticketCount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                // Check if the ticket count is valid
                isTicketCountValid();
                updateTotalPrice();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        // Set an itemSelectedListener for the trainSpinner
        trainSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                SpinnerItemModel selectedSpinnerItemModel = (SpinnerItemModel) parentView.getItemAtPosition(position);
                String selectedValue = selectedSpinnerItemModel.getValue();
                if (!selectedValue.isEmpty()) {
                    selectedTrainValue = selectedValue;
                    // Load train details based on the selected train
                    loadTrainDetails(selectedValue);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {}
        });
    }

    // This method checks if the reservation date is within 30 days from the booking date
    private boolean isReservationDateValid() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // You may need to adjust the date format

        try {
            // Get the current date
            Date currentDate = new Date();
            String bookingDateStr = sdf.format(currentDate);

            // Get the reservation date from the travelDate EditText
            String reservationDateStr = travelDate.getText().toString();

            // Parse the booking and reservation dates
            Date bookingDate = sdf.parse(bookingDateStr);
            Date reservationDate = sdf.parse(reservationDateStr);

            // Calculate the difference in days
            long differenceInMillis = reservationDate.getTime() - bookingDate.getTime();
            long differenceInDays = differenceInMillis / (24 * 60 * 60 * 1000);

            // Check if the difference is within 30 days
            if (differenceInDays >= 0 && differenceInDays <= 30) {
                return true;
            } else {
                showToast("Booking should be within 01 month (30 days).");
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            showToast("Invalid date format. Please enter the date in yyyy-MM-dd format.");
            return false; // Handle parsing errors here
        }
    }


    // Check if a train is selected in the spinner
    private boolean isTrainSelected() {
        return trainSpinner.getSelectedItemPosition() != 0;
    }

    // Check if the ticket count is valid and within the allowed limit
    private boolean isTicketCountValid() {
        String countText = ticketCount.getText().toString();
        if (!countText.isEmpty()) {
            int ticketCountValue = Integer.parseInt(countText);
            if (ticketCountValue > MAX_TICKET_COUNT) {
                // If the ticket count exceeds the maximum, show a message and set the field to the maximum count
                showToast("Ticket count should not exceed " + MAX_TICKET_COUNT);
                ticketCount.setText(String.valueOf(MAX_TICKET_COUNT));
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    // Check if the total price is valid, and update it if so
    private boolean isTotalPriceValid() {
        String priceText = ticketPrice.getText().toString();
        String countText = ticketCount.getText().toString();

        if (!priceText.isEmpty() && !countText.isEmpty()) {
            double price = Double.parseDouble(priceText);
            int count = Integer.parseInt(countText);
            double totalPriceValue = price * count;
            totalPrice.setText(String.valueOf(totalPriceValue));
            return true;
        } else {
            return false;
        }
    }

    // Show a toast message
    private void showToast(String message) {
        Toast.makeText(CreateReservationActivity.this, message, Toast.LENGTH_LONG).show();
    }

    // Update the total price based on ticket price and count
    private void updateTotalPrice() {
        if (isTotalPriceValid()) {
            isTotalPriceValid();
        } else {
            totalPrice.setText("0");
        }
    }

    // Load train data from the server
    private void loadTrainData() {
        String url = endpoint + "api/Train";
        // Populate the train spinner with data from the server
        StringRequest trainRequest = new StringRequest(Request.Method.GET, url, this::populateTrainSpinner, System.out::println) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue trainRequestQueue = Volley.newRequestQueue(CreateReservationActivity.this);
        trainRequest.setRetryPolicy(new DefaultRetryPolicy(50000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        trainRequestQueue.add(trainRequest);
    }

    // Populate the train spinner with data from the server
    private void populateTrainSpinner(String response) {
        List<SpinnerItemModel> spinnerItemModels = new ArrayList<>();
        spinnerItemModels.add(new SpinnerItemModel("Select Train", ""));

        try {
            JSONArray jsonArray = new JSONArray(response);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                spinnerItemModels.add(new SpinnerItemModel("Name: " + jsonObject.getString("name") + " Start : " + jsonObject.getString("start") + " End : " + jsonObject.getString("end"), jsonObject.getString("id")));
            }

            ArrayAdapter<SpinnerItemModel> adapter = new ArrayAdapter<>(CreateReservationActivity.this, android.R.layout.simple_spinner_item, spinnerItemModels);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            trainSpinner.setAdapter(adapter);
        } catch (JSONException ex) {
            throw new RuntimeException(ex);
        }
    }

    // Load train details based on the selected train from the server
    private void loadTrainDetails(String selectedValue) {
        String trainDetailsUrl = endpoint + "api/Train/" + selectedValue;
        StringRequest trainDetailsRequest = new StringRequest(Request.Method.GET, trainDetailsUrl, response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                String[] dateTime = jsonObject.getString("dateTime").split(" | ");
                travelDate.setText(dateTime[0]);
                travelTime.setText(dateTime[2]);
                startStation.setText(jsonObject.getString("start"));
                endStation.setText(jsonObject.getString("end"));
                ticketPrice.setText(jsonObject.getString("price"));
            } catch (JSONException ex) {
                throw new RuntimeException(ex);
            }
            System.out.println(response);
        }, System.out::println) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue trainDetailsRequestQueue = Volley.newRequestQueue(CreateReservationActivity.this);
        trainDetailsRequest.setRetryPolicy(new DefaultRetryPolicy(50000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        trainDetailsRequestQueue.add(trainDetailsRequest);
    }

    // Send ticket data to the server
    private void postTicketData(final SharedPreferences userPreferences) {
        String url = endpoint + "api/Ticket";
        StringRequest request = new StringRequest(Request.Method.POST, url, response -> {
            // Clear the form, show a toast message, and navigate to the booking list activity
            clearForm();
            showToast(response);
            startActivity(new Intent(CreateReservationActivity.this, ReservationsListActivity.class));
        }, System.out::println) {
            @Override
            public byte[] getBody() {
                // Create a JSON object with ticket data and send it as the request body
                JSONObject postData = new JSONObject();
                try {
                    postData.put("trainId", selectedTrainValue);
                    postData.put("dateTime", travelDate.getText().toString() + " | " + travelTime.getText().toString());
                    postData.put("start", startStation.getText().toString());
                    postData.put("end", endStation.getText().toString());
                    postData.put("price", ticketPrice.getText().toString());
                    postData.put("noOfTicket", ticketCount.getText().toString());
                    postData.put("userId", userPreferences.getString("id", null));
                    postData.put("total", totalPrice.getText().toString());
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }

                System.out.println(postData);
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(CreateReservationActivity.this);
        request.setRetryPolicy(new DefaultRetryPolicy(50000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);
    }

    // Clear all form fields
    private void clearForm() {
        travelDate.setText("");
        travelTime.setText("");
        ticketCount.setText("");
        ticketPrice.setText("");
        totalPrice.setText("");
        startStation.setText("");
        endStation.setText("");
        trainSpinner.setSelection(0);
    }
}
