/*
 * File: DashboardActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application user dashboard that allows the user to navigate to the desired activity.
 * Reference: https://www.youtube.com/watch?v=GgtmJSHMeLA
 */

package com.assignment.ead.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import com.assignment.ead.R;

public class DashboardActivity extends AppCompatActivity {

    // UI elements
    ImageView profile, booking, bookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the content view to the dashboard activity layout
        setContentView(R.layout.activity_dashboard);

        // Initialize ImageViews for profile, booking, and booking list
        profile = findViewById(R.id.user_button);
        booking = findViewById(R.id.booking_button);
        bookList = findViewById(R.id.book_list_button);

        // Set click listeners for each ImageView to navigate to respective activities
        profile.setOnClickListener(v -> {
            // Start UserProfileActivity when the profile ImageView is clicked
            startActivity(new Intent(DashboardActivity.this, UserProfileActivity.class));
        });

        booking.setOnClickListener(v -> {
            // Start CreateReservationActivity when the booking ImageView is clicked
            startActivity(new Intent(DashboardActivity.this, CreateReservationActivity.class));
        });

        bookList.setOnClickListener(v -> {
            // Start ReservationsListActivity when the booking list ImageView is clicked
            startActivity(new Intent(DashboardActivity.this, ReservationsListActivity.class));
        });
    }
}
