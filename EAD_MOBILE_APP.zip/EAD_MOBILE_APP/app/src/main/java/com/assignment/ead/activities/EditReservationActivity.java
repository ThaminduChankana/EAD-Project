/*
 * File: EditReservationActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to edit a previously made reservation.
 * References: https://www.youtube.com/watch?v=-61IHhvDvJI
 *             https://www.youtube.com/watch?v=pLM_Fz8Plbg
 *             https://www.youtube.com/watch?v=xPi-z3nOcn8&t=491s
 */
package com.assignment.ead.activities;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.R;
import com.assignment.ead.models.ReservationModel;
import com.assignment.ead.models.SpinnerItemModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class EditReservationActivity extends AppCompatActivity {
    private ReservationModel selectedReservationModel;

    // UI elements
    private Button submitButton;
    private Spinner trainSpinner;
    private EditText dateEditText, timeEditText, startEditText, endEditText, priceEditText, ticketEditText, totalEditText;
    private String selectedTrainValue = "";
    private List<SpinnerItemModel> trainItemsList;

    private static final int MAX_TICKET_COUNT = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content view to the edit F activity layout
        setContentView(R.layout.activity_edit_reservation);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Retrieve user preferences
        SharedPreferences userPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);

        // Initialize UI elements
        trainSpinner = findViewById(R.id.reservation_train);
        dateEditText = findViewById(R.id.reservation_date);
        timeEditText = findViewById(R.id.reservation_time);
        startEditText = findViewById(R.id.reservation_start);
        endEditText = findViewById(R.id.reservation_end);
        priceEditText = findViewById(R.id.reservation_price);
        ticketEditText = findViewById(R.id.reservation_no_of_ticket);
        totalEditText = findViewById(R.id.reservation_total);

        submitButton = findViewById(R.id.reservation_btn);

        // Set click listener for the submit button
        submitButton.setOnClickListener(view -> {
            if (!(trainSpinner.getSelectedItemPosition() == 0)) {
                if (!(ticketEditText.getText().toString().isEmpty() || ticketEditText.getText().toString() == null)) {
                    if (!(totalEditText.getText().toString().isEmpty() || totalEditText.getText().toString() == null)) {
                        // Build the URL for the PUT request
                        String url = endpoint + "api/Ticket/" + selectedReservationModel.getId();
                        StringRequest putRequest = new StringRequest(Request.Method.PUT, url,
                                response -> {
                                    // Clear form data, show a toast message, and navigate to the Reservations list activity on success
                                    clearFormData();
                                    Toast.makeText(EditReservationActivity.this, response, Toast.LENGTH_LONG).show();
                                    startActivity(new Intent(EditReservationActivity.this, ReservationsListActivity.class));
                                },
                                System.out::println) {
                            @Override
                            public byte[] getBody() throws AuthFailureError {
                                // Create a JSON object with updated ticket data and send it as the request body
                                JSONObject postData = new JSONObject();
                                try {
                                    postData.put("id", selectedReservationModel.getId());
                                    postData.put("trainId", selectedTrainValue);
                                    postData.put("dateTime", dateEditText.getText().toString() + " | " + timeEditText.getText().toString());
                                    postData.put("start", startEditText.getText().toString());
                                    postData.put("end", endEditText.getText().toString());
                                    postData.put("price", priceEditText.getText().toString());
                                    postData.put("noOfTicket", ticketEditText.getText().toString());
                                    postData.put("userId", userPreferences.getString("id", null));
                                    postData.put("total", totalEditText.getText().toString());
                                } catch (JSONException ex) {
                                    ex.printStackTrace();
                                }
                                System.out.println(postData);
                                return postData.toString().getBytes();
                            }

                            @Override
                            public String getBodyContentType() {
                                return "application/json";
                            }
                        };

                        RequestQueue requestQueue = Volley.newRequestQueue(EditReservationActivity.this);
                        putRequest.setRetryPolicy(new DefaultRetryPolicy(
                                50000,
                                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                        requestQueue.add(putRequest);
                    } else {
                        Toast.makeText(EditReservationActivity.this, "Total Price Calculation Error!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(EditReservationActivity.this, "Required No Of Ticket!", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(EditReservationActivity.this, "Select Train!", Toast.LENGTH_LONG).show();
            }
        });

        // TextWatcher for the ticketEditText to update totalEditText when ticket count changes
        ticketEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                if (!ticketEditText.getText().toString().isEmpty()) {
                    int enteredTickets = Integer.parseInt(ticketEditText.getText().toString());
                    if (enteredTickets > MAX_TICKET_COUNT) {
                        ticketEditText.setText(String.valueOf(MAX_TICKET_COUNT));
                        enteredTickets = MAX_TICKET_COUNT;
                        showToast("Maximum ticket count exceeded!");
                    }
                    if (!priceEditText.getText().toString().isEmpty() && Double.parseDouble(priceEditText.getText().toString()) > 0) {
                        double value = Double.parseDouble(priceEditText.getText().toString()) * enteredTickets;
                        totalEditText.setText(String.valueOf(value));
                    }
                } else {
                    totalEditText.setText("0");
                }
            }

            // Show a toast message
            private void showToast(String message) {
                Toast.makeText(EditReservationActivity.this, message, Toast.LENGTH_LONG).show();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!ticketEditText.getText().toString().isEmpty()) {
                    int enteredTickets = Integer.parseInt(ticketEditText.getText().toString());
                    if (enteredTickets > MAX_TICKET_COUNT) {
                        ticketEditText.setText(String.valueOf(MAX_TICKET_COUNT));
                        enteredTickets = MAX_TICKET_COUNT;
                        showToast("Maximum ticket count exceeded!");
                    }
                    if (!priceEditText.getText().toString().isEmpty() && Double.parseDouble(priceEditText.getText().toString()) > 0) {
                        double value = Double.parseDouble(priceEditText.getText().toString()) * enteredTickets;
                        totalEditText.setText(String.valueOf(value));
                    }
                } else {
                    totalEditText.setText("0");
                }
            }
        });

        // Initialize the URL for fetching train data
        final String[] trainUrl = {endpoint + "api/Train"};

        // Create a StringRequest to fetch train data from the API
        StringRequest trainRequest = new StringRequest(Request.Method.GET, trainUrl[0],
                response -> {
                    // Initialize the trainItemsList to store spinner items
                    trainItemsList = new ArrayList<>();
                    try {
                        JSONArray jsonArray = new JSONArray(response);

                        // Add a default item to the spinner
                        trainItemsList.add(new SpinnerItemModel("Select Train", ""));

                        // Parse the JSON response and create SpinnerItemModel objects
                        for (int k = 0; k < jsonArray.length(); k++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(k);
                            trainItemsList.add(new SpinnerItemModel("Name: " + jsonObject.getString("name") + " Start : " + jsonObject.getString("start") + " End : " + jsonObject.getString("end"), jsonObject.getString("id")));
                        }

                        // Create an ArrayAdapter for the trainSpinner
                        ArrayAdapter<SpinnerItemModel> adapter = new ArrayAdapter<>(EditReservationActivity.this, android.R.layout.simple_spinner_item, trainItemsList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        trainSpinner.setAdapter(adapter);

                        // Get the selected reservation from the intent and populate the form fields
                        Intent intent = getIntent();
                        selectedReservationModel = (ReservationModel) intent.getSerializableExtra("ReservationModel");
                        dateEditText.setText(selectedReservationModel.getDate());
                        timeEditText.setText(selectedReservationModel.getTime());
                        ticketEditText.setText(selectedReservationModel.getNoOfTickets());
                        priceEditText.setText(selectedReservationModel.getPrice());
                        totalEditText.setText(selectedReservationModel.getTotal());
                        startEditText.setText(selectedReservationModel.getStart());
                        endEditText.setText(selectedReservationModel.getEnd());

                        // Set the selected item in the trainSpinner based on the reservation's train ID
                        setTrainSpinner(selectedReservationModel.getTrainId());
                    } catch (JSONException ex) {
                        throw new RuntimeException(ex);
                    }
                    System.out.println(response);
                },
                System.out::println) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        // Create a request queue for the trainRequest
        RequestQueue trainRequestQueue = Volley.newRequestQueue(EditReservationActivity.this);

        // Set retry policy and add the trainRequest to the queue
        trainRequest.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        trainRequestQueue.add(trainRequest);

        // Set an item selected listener for the trainSpinner
        trainSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                SpinnerItemModel selectedSpinnerItemModel = (SpinnerItemModel) parentView.getItemAtPosition(position);
                String selectedValue = selectedSpinnerItemModel.getValue();
                if (!selectedValue.equals("")) {
                    selectedTrainValue = selectedValue;
                    String url = endpoint + "api/Train/" + selectedValue;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            response -> {
                                try {
                                    JSONObject jsonObject = new JSONObject(response);
                                    System.out.println(jsonObject);
                                    String[] data = jsonObject.getString("dateTime").split(" | ");
                                    System.out.println(data);
                                    dateEditText.setText(data[0]);
                                    timeEditText.setText(data[2]);
                                    startEditText.setText(jsonObject.getString("start"));
                                    endEditText.setText(jsonObject.getString("end"));
                                    priceEditText.setText(jsonObject.getString("price"));
                                } catch (JSONException ex) {
                                    throw new RuntimeException(ex);
                                }
                                System.out.println(response);
                            },
                            System.out::println) {
                        @Override
                        public String getBodyContentType() {
                            return "application/json";
                        }
                    };

                    // Create a request queue for the stringRequest
                    RequestQueue requestQueue = Volley.newRequestQueue(EditReservationActivity.this);

                    // Set retry policy and add the stringRequest to the queue
                    stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                            50000,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                    requestQueue.add(stringRequest);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });
    }

    // Set the selected item in the trainSpinner based on the train ID
    private void setTrainSpinner(String value) {
        int positionToSelect = 0;
        for (int k = 0; k < trainItemsList.size(); k++) {
            if (trainItemsList.get(k).getValue().equals(value)) {
                positionToSelect = k;
                break;
            }
        }
        trainSpinner.setSelection(positionToSelect);
    }

    // Clear form data
    private void clearFormData() {
        dateEditText.setText("");
        timeEditText.setText("");
        ticketEditText.setText("");
        priceEditText.setText("");
        totalEditText.setText("");
        startEditText.setText("");
        endEditText.setText("");
        trainSpinner.setSelection(0);
    }
}
