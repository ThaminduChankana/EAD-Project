/*
 * File: LoginActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to login to the system.
 * References: https://www.youtube.com/watch?v=zkiGwNiSKLI&list=PLT3-dzFEBix1HZJFkMFEOw7e9hR0qUE0D
 *             https://www.youtube.com/watch?v=ksHLKdurXK8
 *             https://stackoverflow.com/questions/65516511/how-to-do-login-using-volley
 *             https://www.youtube.com/watch?v=xPi-z3nOcn8&t=491s
 */

package com.assignment.ead.activities;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.R;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    // UI elements
    private Button registerButton;
    private Button loginButton;
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the content view to the login activity layout
        setContentView(R.layout.activity_login);

        // Initialize UI elements
        initializeViews();

        // Set click listeners for buttons
        setClickListeners();
    }

    // Initialize UI elements
    private void initializeViews() {
        usernameEditText = findViewById(R.id.login_username);
        passwordEditText = findViewById(R.id.login_password);
        loginButton = findViewById(R.id.login_btn);
        registerButton = findViewById(R.id.login_register);
    }

    // Set click listeners for buttons
    private void setClickListeners() {
        registerButton.setOnClickListener(view -> openRegisterActivity());
        loginButton.setOnClickListener(view -> attemptLogin());
    }

    // Open the registration activity
    private void openRegisterActivity() {
        startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
    }

    // Attempt user login
    private void attemptLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Validate username and password
        String validationError = getValidationError(username, password);
        if (validationError == null) {
            String url = endpoint + "api/User/login/" + username + "/" + password;
            performLogin(url);
        } else {
            showToast(validationError);
        }
    }

    // Validate the username format
    private boolean isValidUsername(String username) {
        return username.matches("^(?=.*[a-z])(?=.*[A-Z])(?!.*\\s).+$");
    }

    // Validate the password format
    private boolean isValidPassword(String password) {
        return password.length() <= 12 && password.matches("^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=!]).*$");
    }

    // Get validation error message for username and password
    private String getValidationError(String username, String password) {
        if (!isValidUsername(username)) {
            return "Invalid username. It should include both uppercase and lowercase letters without spaces.";
        }

        if (!isValidPassword(password)) {
            return "Invalid password. It should be at most 12 characters long and contain letters, numbers, and special characters.";
        }

        return null;
    }

    // Perform user login by making a GET request to the server
    private void performLogin(String url) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                this::handleLoginResponse,
                this::handleLoginError) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        setRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    // Handle the response from the login request
    private void handleLoginResponse(String response) {
        if (response.equals("User not found")) {
            showToast(response);
        } else if (response.equals("Unsuccessful")) {
            showToast("Wrong Password!");
        } else {
            try {
                JSONObject obj = new JSONObject(response);
                if (obj.getString("activation").equals("true") && obj.getString("privilege").equals("0")) {
                    // Save user data to SharedPreferences, show a success message, and open the dashboard activity
                    saveUserData(obj);
                    showToast("Login Successful!");
                    openDashboardActivity();
                    finish();
                } else if (!obj.getString("privilege").equals("0")) {
                    showToast("Use WEB App!");
                } else if (obj.getString("activation").equals("false")) {
                    showToast("Your Account Deactivated!");
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
    }

    // Save user data to SharedPreferences
    private void saveUserData(JSONObject userData) {
        SharedPreferences preferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("id", userData.optString("id"));
        editor.putString("name", userData.optString("name"));
        editor.putString("nic", userData.optString("nic"));
        editor.putString("username", userData.optString("username"));
        editor.putString("password", userData.optString("password"));
        editor.putString("privilege", userData.optString("privilege"));
        editor.putString("activation", userData.optString("activation"));
        editor.apply();
    }

    // Open the dashboard activity
    private void openDashboardActivity() {
        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
    }

    // Handle login error, show an error message
    private void handleLoginError(VolleyError error) {
        if (error.networkResponse.statusCode == 404) {
            showToast("NIC already Exists");
        } else {
            showToast("Login Unsuccessful!");
        }
        System.out.println(error);
    }

    // Show a toast message
    private void showToast(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
    }

    // Set a retry policy for the request
    private void setRetryPolicy(StringRequest request) {
        request.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }
}
