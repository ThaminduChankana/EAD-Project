/*
 * File: RegisterActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to reg to the system.
 * References: https://www.youtube.com/watch?v=GPUy5ctU8yw
 *             https://www.youtube.com/watch?v=2czTEn0eIB4
 *             https://stackoverflow.com/questions/54386920/user-registration-using-volley-library-in-android
 *             https://www.youtube.com/watch?v=xPi-z3nOcn8&t=491s
 */
package com.assignment.ead.activities;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.R;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    // UI elements
    private EditText nameEditText;
    private EditText usernameEditText;
    private Button submitButton;
    private TextView loginTextView;
    private EditText nicEditText;
    private EditText passwordEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the content view to the register activity layout
        setContentView(R.layout.activity_register);

        // Initialize UI elements
        initializeViews();

        // Set click listeners for buttons
        setClickListeners();
    }

    // Initialize UI elements
    private void initializeViews() {
        nameEditText = findViewById(R.id.reg_name);
        usernameEditText = findViewById(R.id.reg_username);
        nicEditText = findViewById(R.id.reg_nic);
        passwordEditText = findViewById(R.id.reg_password);
        submitButton = findViewById(R.id.reg_btn);
        loginTextView = findViewById(R.id.reg_login);
    }

    // Set click listeners for buttons
    private void setClickListeners() {
        // Click listener for the "Login" TextView
        loginTextView.setOnClickListener(this::openLoginActivity);

        // Click listener for the "Submit" button
        submitButton.setOnClickListener(this::attemptRegistration);
    }

    // Open the login activity
    private void openLoginActivity(View view) {
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
    }

    // Attempt user registration
    private void attemptRegistration(View view) {
        String name = nameEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String nic = nicEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Validate name, username, NIC, and password
        String validationError = getValidationError(name, username, nic, password);
        if (validationError == null) {
            performRegistration(name, username, nic, password);
        } else {
            showToast(validationError);
        }
    }

    // Validate the name format
    private boolean isValidName(String name) {
        return name.matches("^[A-Za-z ]+$");
    }

    // Validate the NIC format
    private boolean isValidNIC(String nic) {
        return nic.length() == 10 && nic.matches("^[A-Za-z0-9]+$");
    }

    // Validate the username format
    private boolean isValidUsername(String username) {
        return username.matches("^(?=.*[a-z])(?=.*[A-Z])(?!.*\\s).+$");
    }

    // Validate the password format
    private boolean isValidPassword(String password) {
        return password.length() <= 12 && password.matches("^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=!]).*$");
    }

    // Get validation error message for name, username, NIC, and password
    private String getValidationError(String name, String username, String nic, String password) {
        if (!isValidName(name)) {
            return "Invalid name. Please use only letters and spaces.";
        }

        if (!isValidNIC(nic)) {
            return "Invalid NIC. It should be exactly 10 characters long and contain only letters and numbers.";
        }

        if (!isValidUsername(username)) {
            return "Invalid username. It should include both uppercase and lowercase letters without spaces.";
        }

        if (!isValidPassword(password)) {
            return "Invalid password. It should be at most 12 characters long and contain letters, numbers, and special characters.";
        }

        return null;
    }

    // Perform user registration by making a POST request to the server
    private void performRegistration(String name, String username, String nic, String password) {
        String url = endpoint + "api/User";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                this::onRegistrationSuccess,
                this::onRegistrationError) {
            @Override
            public byte[] getBody() {
                JSONObject postData = new JSONObject();
                try {
                    postData.put("name", name);
                    postData.put("nic", nic);
                    postData.put("username", username);
                    postData.put("password", password);
                    postData.put("privilege", 0);
                    postData.put("activation", true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                System.out.println(postData);
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(RegisterActivity.this);
        setRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    // Handle successful registration, show a success message and open the login activity
    private void onRegistrationSuccess(String response) {
        showToast(response);
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        finish();
    }

    // Handle registration error, show an error message
    private void onRegistrationError(VolleyError error) {
        if (error.networkResponse != null && error.networkResponse.statusCode == 404) {
            showToast("Existing NIC");
        } else {
            showToast("Registration Unsuccessful!");
        }
        System.out.println(error);
    }

    // Show a toast message
    private void showToast(String message) {
        Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_LONG).show();
    }

    // Set a retry policy for the request
    private void setRetryPolicy(StringRequest request) {
        request.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }
}
