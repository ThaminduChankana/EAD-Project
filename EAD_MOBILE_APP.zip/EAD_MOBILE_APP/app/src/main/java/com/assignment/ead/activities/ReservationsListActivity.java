/*
 * File: ReservationsListActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to view added reservations by the user.
 * References: https://www.youtube.com/watch?v=xPi-z3nOcn8&t=491s
 *             https://www.youtube.com/watch?v=xPi-z3nOcn8&t=495s
 *             https://www.itsalif.info/content/android-volley-tutorial-http-get-post-put
 *             https://www.youtube.com/watch?v=o1m2RicWnjo
 *             https://www.youtube.com/watch?v=Ev6EcQwvFSs&list=PLirRGafa75rRe9PJ9t-5KDEuCmfsA_rZr
 */
package com.assignment.ead.activities;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.WindowManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.R;
import com.assignment.ead.adapters.ReservationAdapter;
import com.assignment.ead.models.ReservationModel;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class ReservationsListActivity extends AppCompatActivity {

    // UI elements

    private RecyclerView reservationListRecyclerView;
    private ReservationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the content view to the reservation list activity layout
        setContentView(R.layout.activity_reservations_list);

        // Initialize RecyclerView and its adapter
        initializeViews();

        // Fetch and display reservations from the server
        fetchAndDisplayBookings();
    }

    // Initialize RecyclerView and its adapter
    private void initializeViews() {
        reservationListRecyclerView = findViewById(R.id.reservation_list_recycler_view);
        reservationListRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ReservationAdapter(new ArrayList<>());
        reservationListRecyclerView.setAdapter(adapter);
    }

    // Fetch and display user's reservations from the server
    private void fetchAndDisplayBookings() {
        // Get user preferences to obtain user ID
        SharedPreferences preferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);
        String url = endpoint + "api/Ticket/user/" + preferences.getString("id", null);

        // Create a network request to retrieve reservation data
        // Handle the response from the server
        // Handle any errors that occur during the request
        StringRequest request = new StringRequest(Request.Method.GET, url, this::handleBookingResponse, this::handleBookingError);

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    // Handle the successful response containing reservation data
    private void handleBookingResponse(String response) {
        ArrayList<ReservationModel> allBookings = new ArrayList<>();
        try {
            // Parse the JSON response and create ReservationModel objects
            JSONArray jsonArray = new JSONArray(response);
            for (int k = 0; k < jsonArray.length(); k++) {
                String[] dateTime = jsonArray.getJSONObject(k).getString("dateTime").split(" | ");
                allBookings.add(new ReservationModel(
                        jsonArray.getJSONObject(k).getString("id"),
                        dateTime[0],
                        dateTime[2],
                        jsonArray.getJSONObject(k).getString("price"),
                        jsonArray.getJSONObject(k).getString("noOfTicket"),
                        jsonArray.getJSONObject(k).getString("start"),
                        jsonArray.getJSONObject(k).getString("end"),
                        jsonArray.getJSONObject(k).getString("trainId"),
                        jsonArray.getJSONObject(k).getString("total"),
                        jsonArray.getJSONObject(k).getString("dateTime")));
            }

            // Update the adapter with the retrieved reservation data
            adapter.setReservations(allBookings);
            adapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // Handle any errors that occur during the reservation data retrieval
    private void handleBookingError(VolleyError error) {
        // Log the error for debugging purposes
        System.out.println(error.toString());
    }
}
