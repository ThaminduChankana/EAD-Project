/*
 * File: SplashScreen.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that displays on the start up.
 * References:https://www.youtube.com/watch?v=Q0gRqbtFLcw
 */

package com.assignment.ead.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import com.assignment.ead.R;

public class SplashScreenActivity extends AppCompatActivity {
    private static final int SPLASH_DELAY = 2000; // Delay time for the splash screen in milliseconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the content view to the splash screen layout
        setContentView(R.layout.activity_splash_screen);

        // Create a new Handler to delay the launch of the LoginActivity
        new Handler().postDelayed(() -> {
            // Start the LoginActivity and finish the splash screen activity
            startActivity(new Intent(SplashScreenActivity.this, LoginActivity.class));
            finish();
        }, SPLASH_DELAY); // Delay for SPLASH_DELAY milliseconds before launching LoginActivity
    }
}
