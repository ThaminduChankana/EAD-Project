/*
 * File: UserProfileActivity.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to update and view user details.
 * References: https://www.youtube.com/watch?v=4_pM2g70IpM
 *             https://www.youtube.com/watch?v=LL8kZKVb9fU
 *             https://www.youtube.com/watch?v=Tfl20xbDijo
 *             https://www.youtube.com/watch?v=-61IHhvDvJI&t=166s
 */
package com.assignment.ead.activities;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.R;

import org.json.JSONException;
import org.json.JSONObject;

public class UserProfileActivity extends AppCompatActivity {

    // UI elements
    private Button saveButton;
    private EditText nameEditText;
    private EditText usernameEditText;
    private EditText nicEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar and set the activity to fullscreen
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_user_profile);

        // Initialize UI elements
        initializeViews();

        // Load user data into the UI
        loadUserData();

        // Set a click listener for the saveButton
        saveButton.setOnClickListener(this::updateUserProfile);
    }

    private void initializeViews() {
        // Initialize EditText and Button views
        nameEditText = findViewById(R.id.user_profile_name);
        usernameEditText = findViewById(R.id.user_profile_username);
        nicEditText = findViewById(R.id.user_profile_nic);
        passwordEditText = findViewById(R.id.user_profile_password);
        saveButton = findViewById(R.id.user_profile_submit_button);
    }

    private void loadUserData() {
        // Load user data from SharedPreferences and set them in EditText fields
        SharedPreferences sharedPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);
        nameEditText.setText(sharedPreferences.getString("name", ""));
        usernameEditText.setText(sharedPreferences.getString("username", ""));
        nicEditText.setText(sharedPreferences.getString("nic", ""));
        passwordEditText.setText(sharedPreferences.getString("password", ""));
    }

    private void updateUserProfile(View view) {
        // Retrieve user input for updating the user profile
        String name = nameEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String nic = nicEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Validate user input
        String validationError = getValidationError(name, username, nic, password);
        if (validationError == null) {
            // Perform the update if input is valid
            performUpdate(name, username, nic, password);
        } else {
            // Show a toast message if there is a validation error
            showToast(validationError);
        }
    }

    // Validation methods for user input
    private boolean isValidName(String name) {
        return name.matches("^[A-Za-z ]+$");
    }

    private boolean isValidNIC(String nic) {
        return nic.length() == 10 && nic.matches("^[A-Za-z0-9]+$");
    }

    private boolean isValidUsername(String username) {
        return username.matches("^(?=.*[a-z])(?=.*[A-Z])(?!.*\\s).+$");
    }

    private boolean isValidPassword(String password) {
        return password.length() <= 12 && password.matches("^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=!]).*$");
    }

    // Validate user input and return an error message if there is any
    private String getValidationError(String name, String username, String nic, String password) {
        if (!isValidName(name)) {
            return "Invalid name. Please use only letters and spaces.";
        }

        if (!isValidNIC(nic)) {
            return "Invalid NIC. It should be exactly 10 characters long and contain only letters and numbers.";
        }

        if (!isValidUsername(username)) {
            return "Invalid username. It should include both uppercase and lowercase letters without spaces.";
        }

        if (!isValidPassword(password)) {
            return "Invalid password. It should be at most 12 characters long and contain letters, numbers, and special characters.";
        }

        return null;
    }

    // Perform the update of the user profile
    private void performUpdate(String name, String username, String nic, String password) {
        // Retrieve user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);
        String userId = sharedPreferences.getString("id", "");

        // Construct the URL for updating the user profile
        String url = endpoint + "api/User/" + userId;

        StringRequest stringRequest = new StringRequest(Request.Method.PUT, url,
                this::handleUpdateResponse,
                error -> handleUpdateError(error, nic)) {
            @Override
            public byte[] getBody() {
                JSONObject postData = new JSONObject();
                try {
                    // Prepare the data for updating
                    postData.put("id", userId);
                    postData.put("name", name);
                    postData.put("nic", nic);
                    postData.put("username", username);
                    postData.put("password", password);
                    postData.put("privilege", 0);
                    postData.put("activation", true);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Print the data for debugging purposes
                System.out.println(postData);
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(UserProfileActivity.this);
        setRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    // Handle the response after updating the user profile
    private void handleUpdateResponse(String response) {
        // Update the local user data stored in SharedPreferences
        updateLocalUserData();
        showToast(response);
        startActivity(new Intent(UserProfileActivity.this, DashboardActivity.class));
    }

    // Update the local user data in SharedPreferences
    private void updateLocalUserData() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("name", nameEditText.getText().toString());
        editor.putString("nic", nicEditText.getText().toString());
        editor.putString("username", usernameEditText.getText().toString());
        editor.putString("password", passwordEditText.getText().toString());
        editor.apply();
    }

    // Handle errors that occur during the update process
    private void handleUpdateError(VolleyError error, String nic) {
        if (error.networkResponse != null && error.networkResponse.statusCode == 404) {
            showToast("NIC Already Exists");
        } else {
            showToast("User Profile Update Unsuccessful!");
        }
        System.out.println(error);
    }

    // Display a toast message
    private void showToast(String message) {
        Toast.makeText(UserProfileActivity.this, message, Toast.LENGTH_LONG).show();
    }

    // Set a retry policy for the Volley request
    private void setRetryPolicy(StringRequest request) {
        request.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }
}
