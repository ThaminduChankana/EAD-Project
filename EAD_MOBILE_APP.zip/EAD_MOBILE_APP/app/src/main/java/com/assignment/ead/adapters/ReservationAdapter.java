/*
 * File: ReservationAdapter.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the mobile application UI that allows the user to manager reservationModels on the reservationModels list.
 * References: https://www.youtube.com/watch?v=gGFvbvkZiMs
 *             https://www.youtube.com/watch?v=tQ7V7iBg5zE
 *             https://www.youtube.com/watch?v=xPi-z3nOcn8&t=512s
 *             https://developer.android.com/develop/ui/views/layout/recyclerview
 */
package com.assignment.ead.adapters;

import static com.assignment.ead.config.API_Endpoint.endpoint;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.ead.activities.EditReservationActivity;
import com.assignment.ead.R;
import com.assignment.ead.models.ReservationModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ReservationViewHolder> {

    private ArrayList<ReservationModel> reservationModels;
    private Context appContext;

    // Constructor to initialize the adapter with a list of reservationModels
    public ReservationAdapter(ArrayList<ReservationModel> reservationModels) {
        this.reservationModels = reservationModels;
    }

    // Create a new ViewHolder when needed
    @NonNull
    @Override
    public ReservationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        appContext = parent.getContext();
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_reservation, parent, false);
        return new ReservationViewHolder(view);
    }

    // Bind data to the ViewHolder and set click listeners
    @Override
    public void onBindViewHolder(@NonNull ReservationViewHolder holder, int position) {
        ReservationModel currentReservationModel = reservationModels.get(position);

        // Bind data to the ViewHolder
        holder.bindData(currentReservationModel);

        // Set click listeners for edit and delete buttons
        holder.editButton.setOnClickListener(view -> {
            // Check if it's at least 5 days before the reservation date
            if (isEditable(currentReservationModel.getDateTime())) {
                Intent intent = new Intent(view.getContext(), EditReservationActivity.class);
                intent.putExtra("ReservationModel", currentReservationModel);
                view.getContext().startActivity(intent);
            } else {
                Toast.makeText(view.getContext(), "Reservations can only be updated at least 5 days before the reservation date.", Toast.LENGTH_LONG).show();
            }
        });

        holder.deleteButton.setOnClickListener(view -> {
            // Check if it's at least 5 days before the reservation date
            if (isCancelable(currentReservationModel.getDateTime())) {
                showDeleteConfirmationDialog(currentReservationModel, position);
            } else {
                Toast.makeText(view.getContext(), "Reservations can only be canceled at least 5 days before the reservation date.", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Helper method to check if it's at least 5 days before the reservation date
    private boolean isEditable(String reservationDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd | HH:mm", Locale.US);
            Date date = sdf.parse(reservationDate);

            // Calculate the date 5 days before the reservation date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, -5);
            Date fiveDaysBefore = calendar.getTime();

            // Check if the current date is at least 5 days before the reservation date
            Date currentDate = new Date();
            return currentDate.before(fiveDaysBefore);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to check if it's at least 5 days before the reservation date for cancelation
    private boolean isCancelable(String reservationDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd | HH:mm", Locale.US);
            Date date = sdf.parse(reservationDate);

            // Calculate the date 5 days before the reservation date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, -5);
            Date fiveDaysBefore = calendar.getTime();

            // Check if the current date is at least 5 days before the reservation date
            Date currentDate = new Date();
            return currentDate.before(fiveDaysBefore);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }
    // Update the list of reservationModels
    public void setReservations(ArrayList<ReservationModel> reservationModels) {
        this.reservationModels = reservationModels;
        notifyDataSetChanged();
    }

    // Get the number of items in the list
    @Override
    public int getItemCount() {
        return reservationModels.size();
    }

    // ViewHolder class to hold the UI elements for each reservation
    static class ReservationViewHolder extends RecyclerView.ViewHolder {
        Button editButton, deleteButton;
        TextView dateTime, start, end, price, noOfTickets, total;

        public ReservationViewHolder(View itemView) {
            super(itemView);
            dateTime = itemView.findViewById(R.id.booking_departure_datetime);
            start = itemView.findViewById(R.id.booking_start_station_tv);
            end = itemView.findViewById(R.id.booking_end_station_tv);
            price = itemView.findViewById(R.id.booking_ticket_price);
            noOfTickets = itemView.findViewById(R.id.booking_num_of_tickets);
            total = itemView.findViewById(R.id.booking_total_price);

            editButton = itemView.findViewById(R.id.edit_booking_button);
            deleteButton = itemView.findViewById(R.id.delete_booking_button);
        }

        // Bind data from the ReservationModel object to UI elements
        @SuppressLint("SetTextI18n")
        public void bindData(ReservationModel reservationModel) {
            dateTime.setText("Date & Time: " + reservationModel.getDateTime());
            price.setText("Ticket Price: " + reservationModel.getPrice());
            start.setText("Start Station" + "\n"+ "\n" +reservationModel.getStart());
            end.setText("End Station" + "\n" + "\n" +reservationModel.getEnd());
            total.setText("Total Ticket Price: " + reservationModel.getTotal() + " LKR");
            noOfTickets.setText("No Of Tickets: " + reservationModel.getNoOfTickets());
        }
    }

    // Show a confirmation dialog for deleting a reservationModel
    private void showDeleteConfirmationDialog(ReservationModel reservationModel, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(appContext);
        builder.setTitle("Delete Reservation");
        builder.setMessage("Delete ?");

        builder.setPositiveButton("Yes", (dialogInterface, i) -> deleteReservation(reservationModel, position));

        builder.setNegativeButton("No", (dialogInterface, i) -> {
            // Do nothing
        });

        builder.show();
    }

    // Delete a reservationModel by making a DELETE request to the API
    private void deleteReservation(ReservationModel reservationModel, int position) {
        String url = endpoint + "api/Ticket/" + reservationModel.getId();

        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, url,
                response -> {
                    // Handle successful deletion
                    Toast.makeText(appContext, response, Toast.LENGTH_LONG).show();
                    reservationModels.remove(position);
                    notifyItemRemoved(position);
                },
                error -> System.out.println(error)
        ) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(appContext);

        // Set a retry policy for the Volley request
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }
}
