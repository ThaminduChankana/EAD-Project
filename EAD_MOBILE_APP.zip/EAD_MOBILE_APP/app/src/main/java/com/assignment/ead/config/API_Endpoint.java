/*
 * File: API_Endpoint.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the API ENDPOINT which connects backend with android application.
 */
package com.assignment.ead.config;

public class API_Endpoint {
    //This is the backend endpoint which is used to connect with backend
    public final static String endpoint="http://172.20.10.9:7096/";

}
