/*
 * File: ReservationModel.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the Model of reservation.
 */
package com.assignment.ead.models;

import java.io.Serializable;

public class ReservationModel implements Serializable {

    private String id;          // Unique identifier for the reservation
    private String date;        // Date of the reservation
    private String time;        // Time of the reservation
    private String price;       // Price of the reservation
    private String noOfTickets; // Number of tickets in the reservation
    private String start;       // Start station of the journey
    private String end;         // End station of the journey
    private String trainId;     // Unique identifier for the train associated with the reservation
    private String total;       // Total price of the reservation
    private String dateTime;    // Date and time of the reservation

    // Constructor to initialize a ReservationModel object with all its properties
    public ReservationModel(String id, String date, String time, String price, String noOfTickets, String start, String end, String trainId, String total, String dateTime) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.price = price;
        this.noOfTickets = noOfTickets;
        this.start = start;
        this.end = end;
        this.trainId = trainId;
        this.total = total;
        this.dateTime = dateTime;
    }

    public String getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getPrice() {
        return price;
    }

    public String getNoOfTickets() {
        return noOfTickets;
    }

    public String getStart() {
        return start;
    }

    public String getEnd() {
        return end;
    }

    public String getTrainId() {
        return trainId;
    }

    public String getTotal() {
        return total;
    }

    public String getDateTime() {
        return dateTime;
    }
}
