/*
 * File: SpinnerItemModel.java
 * Author: Gamage T.C.M
 * Date: October 9, 2023
 * Description: This is the Model of Spinner of the train Selector.
 */
package com.assignment.ead.models;

public class SpinnerItemModel {
    private String label;  // The display label for the spinner item
    private String value;  // The corresponding value associated with the spinner item

    // Constructor to initialize a SpinnerItemModel object with label and value
    public SpinnerItemModel(String label, String value) {
        this.label = label;
        this.value = value;
    }

    // Getter method to retrieve the label of the spinner item
    public String getLabel() {
        return label;
    }

    // Getter method to retrieve the value of the spinner item
    public String getValue() {
        return value;
    }

    // Override the toString method to return the label when the object is treated as a string
    @Override
    public String toString() {
        return label;
    }
}
